Создание онлайн-магазина кроссовок 
--
Использованы технологии - React,React Router v6, Redux, Axios, CSS modules, Sass, 

